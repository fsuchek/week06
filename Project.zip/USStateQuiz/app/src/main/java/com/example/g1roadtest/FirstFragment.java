package com.example.g1roadtest;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class FirstFragment extends Fragment {
    public static final String TAG = "USStateQuiz Activity";
    public static int STATES_IN_QUIZ = 10;

    private List<String> filenameList;
    private Set<String> regionSet;
    private List<String> usStateList; //list of all us states

    private String correctAnswer; //correct US state for current quiz
    private static int totalGuesses; //number of guesses made
    private int correctAnswers; //number of correct guesses

    private SecureRandom random; //used to random quiz
    private Handler handler;

    private LinearLayout quizLinearLayout; //layout that contains the quiz
    private TextView questionNumberTextView; //shows the current question
    private ImageView stateOutlineImageView;
    private LinearLayout[] guessLinearLayouts;
    private TextView answerTextView; //displays correct answer
    private int guessRows;

    private View.OnClickListener guessButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Button guessButton = ((Button) view);
            String guess = guessButton.getText().toString();
            String answer = getStateName(correctAnswer);
            ++totalGuesses;

            if (guess.equals(answer)) {
                ++correctAnswers;

                if (correctAnswers == STATES_IN_QUIZ) {
                    DialogFragment quizResults = new MyDialogFragment();

                    quizResults.setCancelable(false);
                    quizResults.show(getFragmentManager(), "quiz results");
                } else {
                    loadNextState();
                }
            } else {
                answerTextView.setText(R.string.incorrect_answer);
                guessButton.setEnabled(false);
            }
        }
    };

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        filenameList = new ArrayList<>();
        usStateList = new ArrayList<>();
        random = new SecureRandom();
        handler = new Handler();
        quizLinearLayout = (LinearLayout) view.findViewById(R.id.quizLinearLayout);
        questionNumberTextView = view.findViewById(R.id.questionNumberText);
        stateOutlineImageView = view.findViewById(R.id.mapImageView);
        guessLinearLayouts = new LinearLayout[4];
        guessLinearLayouts[0] = view.findViewById(R.id.row1LinearLayout);
        guessLinearLayouts[1] = view.findViewById(R.id.row2LinearLayout);
        guessLinearLayouts[2] = view.findViewById(R.id.row3LinearLayout);
        guessLinearLayouts[3] = view.findViewById(R.id.row4LinearLayout);
        answerTextView = view.findViewById(R.id.answerTextView);
        for (LinearLayout row : guessLinearLayouts) {
            for (int column = 0; column < row.getChildCount(); column++) {
                Button button = (Button) row.getChildAt(column);
                button.setOnClickListener(guessButtonListener);
            }
        }
        questionNumberTextView.setText(getString(R.string.question, 1, STATES_IN_QUIZ));
        // Inflate the layout for this fragment
        return view;
    }

    private void loadNextState() {
        String nextImage = usStateList.remove(0);
        correctAnswer = nextImage;
        answerTextView.setText("");

        questionNumberTextView.setText(getString(R.string.question, (correctAnswers + 1), STATES_IN_QUIZ));

        String region = nextImage.substring(0, nextImage.indexOf('_'));

        AssetManager assets = getActivity().getAssets();

        try {
            InputStream stream = assets.open(region + "/" + nextImage + ".jpg");

            Drawable stateOutline = Drawable.createFromStream(stream, nextImage);
            stateOutlineImageView.setImageDrawable(stateOutline);
        } catch (Exception e) {
            Log.e(TAG, "Error loading " + nextImage, e);
        }

        Collections.shuffle(filenameList);
        int correct = filenameList.indexOf(correctAnswer);
        filenameList.add(filenameList.remove(correct));

        for (int row = 0; row < guessRows; row++) {
            for (int column = 0; column < guessLinearLayouts[row].getChildCount(); column++) {
                Button newGuessButton = (Button) guessLinearLayouts[row].getChildAt(column);
                newGuessButton.setEnabled(true);

                String filename = filenameList.get((row * 2) + column);
                newGuessButton.setText(getStateName(filename));
            }
        }

        int row = random.nextInt(guessRows);
        int col = random.nextInt(2);
        LinearLayout randomRow = guessLinearLayouts[row];
        String countryName = getStateName(correctAnswer);
        ((Button) randomRow.getChildAt(col)).setText(countryName);
    }

    public void resetQuiz() {

        AssetManager assets = getActivity().getAssets();
        filenameList.clear();

        //For now we will pull from all regions. Later we will select specific
        // regions as part of the settings
        //regionSet = (Set<String>) new ArrayList<String>();
        //regionSet. add("Midwest") ;

        //regionSet. add("Northeast”") ;
        //regionSet.add("Southeast") ;
        //regionSet.add("Southwest”") ;
        //regionSet.add("West") ;


        try {
            for (String region : regionSet) {
                String[] paths = assets.list(region);
                for (String path : paths) {
                    filenameList.add(path.replace(".jpg", ""));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        correctAnswers = 0;
        totalGuesses = 0;
        usStateList.clear();

        int stateCounter = 1;
        int numberOfStates = filenameList.size();

        while (stateCounter <= STATES_IN_QUIZ) {
            int randomIndex = random.nextInt(numberOfStates);
            String filename = filenameList.get(randomIndex);

            if (!usStateList.contains(filename)) {
                usStateList.add(filename);
                ++stateCounter;
            }
        }
        loadNextState();
    }

    private String getStateName(String name) {
        return name.substring(name.indexOf("_") + 1).replace("_", " ");
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    public static class MyDialogFragment extends DialogFragment {
        public MyDialogFragment() {
        }

        @Override
        public Dialog onCreateDialog(Bundle bundle) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage(getString(R.string.results, totalGuesses, (1000 / (double) totalGuesses)));

            builder.setPositiveButton(R.string.reset_quiz, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                            quizFragment().resetQuiz();
                        }
                    }
            );
            return builder.create();
        }

        private FirstFragment quizFragment() {
            return (FirstFragment) getFragmentManager().findFragmentById(R.id.quizFragment);
        }
    }

    public void updateGuessRows(SharedPreferences sharedPreferences) {
        String choices = sharedPreferences.getString(MainActivity.CHOICES, null);
        guessRows = Integer.parseInt(choices) / 2;

        for (LinearLayout layout : guessLinearLayouts)
            layout.setVisibility(View.GONE);

        for (int row = 0; row < guessRows; row++) {
            guessLinearLayouts[row].setVisibility(View.VISIBLE);
        }
    }

    public void updateRegion(SharedPreferences sharedPreferences) {
        regionSet = sharedPreferences.getStringSet(MainActivity.REGIONS, null);
    }
}